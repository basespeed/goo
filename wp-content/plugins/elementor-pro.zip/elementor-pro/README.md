# Elementor Pro

This is just a mirror from the zip you would normally download from elementor.com, meaning that you still need a valid license to activate this plugin. No copyright infringement done.

This repository is a stop-gap solution until [elementor/elementor#4042](https://github.com/elementor/elementor/issues/4042) is addressed.

If you want to use this repository on your composer managed wordpress installation, follow [these instructions](https://roots.io/guides/private-or-commercial-wordpress-plugins-as-composer-dependencies/) (skip to "Edit your Bedrock `composer.json` file, add your repository and plugin").

I will keep updating this repository on a best effort basis, but feel free to open a PR if I lag behind.
