<?php
//Include Widgets files
//path 'widgets/../file.php';

$include_widgets_files = array(
    //'Header/Header1.php'
);
