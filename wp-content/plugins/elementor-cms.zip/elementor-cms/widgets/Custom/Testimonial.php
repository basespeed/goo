<?php
namespace ElementorCMS\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Header
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Testimonial extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    protected $nav_menu_index = 1;
    public function get_name() {
        return 'testimonial_custom';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Testimonial', 'elementor-cms' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-review';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'saokim-cms-custom' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'elementor-cms' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function get_nav_menu_index() {
        return $this->nav_menu_index++;
    }

    private function get_available_menus() {
        $menus = wp_get_nav_menus();

        $options = [];

        foreach ( $menus as $menu ) {
            $options[ $menu->slug ] = $menu->name;
        }

        return $options;
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'elementor-cms' ),
            ]
        );

        /*$this->add_control(
            'slides_per_view',
            [
                'label' => __( 'Slides Per View', 'elementor-cms' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Slides Per View', 'elementor-cms' ),
            ]
        );*/

        $this->add_control(
            'slides_per_view',
            [
                'label' => __( 'Slides Per View', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '1'  => __( '1', 'elementor-cms' ),
                    '2' => __( '2', 'elementor-cms' ),
                    '3' => __( '3', 'elementor-cms' ),
                    '4' => __( '4', 'elementor-cms' ),
                    '5' => __( '5', 'elementor-cms' ),
                    '6' => __( '6', 'elementor-cms' ),
                    '7' => __( '7', 'elementor-cms' ),
                    '8' => __( '8', 'elementor-cms' ),
                    '9' => __( '9', 'elementor-cms' ),
                    '10' => __( '10', 'elementor-cms' ),
                ],
            ]
        );

        $this->add_control(
            'margin_item',
            [
                'label' => __( 'Margin Item', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '30',
                'options' => [
                    '10'  => __( '10', 'elementor-cms' ),
                    '15' => __( '15', 'elementor-cms' ),
                    '20' => __( '20', 'elementor-cms' ),
                    '25' => __( '25', 'elementor-cms' ),
                    '30' => __( '30', 'elementor-cms' ),
                    '35' => __( '35', 'elementor-cms' ),
                    '40' => __( '40', 'elementor-cms' ),
                    '45' => __( '45', 'elementor-cms' ),
                    '50' => __( '50', 'elementor-cms' ),
                ],
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => __( 'Loop', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1'  => __( 'True', 'elementor-cms' ),
                    '2' => __( 'False', 'elementor-cms' ),
                ],
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Autoplay', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'options' => [
                    '1'  => __( 'Enable', 'elementor-cms' ),
                    '2' => __( 'Disable', 'elementor-cms' ),
                ],
            ]
        );

        $this->add_control(
            'autoplay_delay',
            [
                'label' => __( 'Autoplay Delay', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 500,
                'max' => 20000,
                'step' => 1000,
                'default' => 1000,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'list_image',
            [
                'label' => __( 'Avatar', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'list_title', [
                'label' => __( 'Title', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'List Title' , 'elementor-cms' ),
                'show_label' => true,
            ]
        );

        $repeater->add_control(
            'list_cate', [
                'label' => __( 'Cate', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'List Cate' , 'elementor-cms' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'list_position',
            [
                'label' => __( 'Position', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'List Position' , 'elementor-cms' ),
                'show_label' => true,
            ]
        );

        $this->add_control(
            'list_testimonials',
            [
                'label' => __( 'Repeater List', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => __( 'Title #1', 'elementor-cms' ),
                        'list_content' => __( 'Item content. Click the edit button to change this text.', 'elementor-cms' ),
                    ],
                    [
                        'list_title' => __( 'Title #2', 'elementor-cms' ),
                        'list_content' => __( 'Item content. Click the edit button to change this text.', 'elementor-cms' ),
                    ],
                ],
                'title_field' => '{{{ list_title }}}',
            ]
        );


        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function render() {
        $settings = $this->get_active_settings();

        //var_dump($settings);
        ?>
        <div class="owl-carousel owl-theme">
            <?php
                if($settings['list_testimonials']) :
                foreach ($settings['list_testimonials'] as $item) :
            ?>
                <div class="item">
                    <div class="img">
                        <img src="<?php echo $item['list_image']['url']; ?>" alt="<?php echo $item['list_title']; ?>"/>
                    </div>
                    <div class="content">
                        <div class="meta"><?php echo $item['list_cate']; ?></div>
                        <div class="title"><?php echo $item['list_title']; ?></div>
                        <div class="position"><?php echo $item['list_position']; ?></div>
                    </div>
                </div>
            <?php
                endforeach;
                endif;
            ?>
        </div>

        <script>
            ( function( $ ) {
                "use strict"

                var owl = $('.owl-carousel');
                owl.owlCarousel({
                    items:<?php echo $settings['slides_per_view']; ?>,
                    loop:<?php if($settings['loop'] == 1){echo 'true';}else{echo 'false';} ?>,
                    margin:<?php echo $settings['margin_item']; ?>,
                    autoplay:<?php if($settings['autoplay'] == 1){echo 'true';}else{echo 'false';} ?>,
                    autoplayTimeout:<?php echo $settings['autoplay_delay']; ?>,
                    autoplayHoverPause:true,
                    nav:true,
                    responsive:{
                        0:{
                            items:1
                        },
                        600:{
                            items:2
                        },
                        1000:{
                            items:<?php echo $settings['slides_per_view']; ?>
                        }
                    }
                });
                $('.play').on('click',function(){
                    owl.trigger('play.owl.autoplay',[1000])
                })
                $('.stop').on('click',function(){
                    owl.trigger('stop.owl.autoplay')
                })

            } )( jQuery );
        </script>
        <?php
    }

    /**
     * Render the widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _content_template() {}
}


