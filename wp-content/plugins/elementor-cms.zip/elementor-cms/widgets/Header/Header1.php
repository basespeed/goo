<?php
namespace ElementorCMS\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Header
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Header1 extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
    protected $nav_menu_index = 1;
	public function get_name() {
		return 'header1';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Header 1', 'elementor-cms' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'icon_sk_header1';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saokim-cms-header' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'elementor-cms' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function get_nav_menu_index() {
        return $this->nav_menu_index++;
    }

    private function get_available_menus() {
        $menus = wp_get_nav_menus();

        $options = [];

        foreach ( $menus as $menu ) {
            $options[ $menu->slug ] = $menu->name;
        }

        return $options;
    }

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'elementor-cms' ),
			]
		);

        $menus = $this->get_available_menus();

        if ( ! empty( $menus ) ) {
            $this->add_control(
                'menu',
                [
                    'label' => __( 'Menu', 'elementor-pro' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => $menus,
                    'default' => array_keys( $menus )[0],
                    'save_default' => true,
                    'separator' => 'after',
                    'description' => sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'elementor-pro' ), admin_url( 'nav-menus.php' ) ),
                ]
            );
        } else {
            $this->add_control(
                'menu',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => '<strong>' . __( 'There are no menus in your site.', 'elementor-pro' ) . '</strong><br>' . sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'elementor-pro' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
                    'separator' => 'after',
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                ]
            );
        }

        $this->add_control(
            'logo_image',
            [
                'label' => __( 'Logo', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'show_search',
            [
                'label' => __( 'Search', 'elementor-cms' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'elementor-cms' ),
                'label_off' => __( 'Hide', 'yelementor-cms' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'short_code',
            [
                'label' => __( 'Short Code', 'elementor-cms' ),
                'type' => Controls_Manager::TEXT,
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'elementor-cms' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'elementor-cms' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'elementor-cms' ),
					'uppercase' => __( 'UPPERCASE', 'elementor-cms' ),
					'lowercase' => __( 'lowercase', 'elementor-cms' ),
					'capitalize' => __( 'Capitalize', 'elementor-cms' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

	protected function render() {
        $settings = $this->get_active_settings();

        $args = [
            'echo' => false,
            'menu' => $settings['menu'],
            'menu_class' => 'elementor-nav-menu',
            'fallback_cb' => '__return_empty_string',
            'container' => '',
        ];

        $menu_html = wp_nav_menu( $args );
		?>
        <header id="header1">
            <div class="logo">
                <a href="<?php home_url(); ?>"><img src="<?php echo $settings['logo_image']['url']; ?>" alt="logo"></a>
            </div>
            <div class="flex-grow"></div>
            <div class="header1_content">
                <nav class="menu"><?php echo $menu_html; ?></nav>
                <?php
                    if($settings['show_search'] == 'yes'){
                        echo '<div class="header1_frm">';
                        echo '<button type="button" class="toggle_search_header1"><i class="fa fa-search" aria-hidden="true"></i></button>';
                        $form = '<form role="search" method="get" class="search-form" action="' . esc_url( home_url( '/' ) ) . '">
                            <label>
                                <span class="screen-reader-text">' . _x( 'Search for:', 'label' ) . '</span>
                                <input type="search" class="search-field" placeholder="' . esc_attr_x( 'Search &hellip;', 'placeholder' ) . '" value="' . get_search_query() . '" name="s" />
                            </label>
                            <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                        </form>';
                        echo $form;
                        echo '</div>';
                    }
                ?>
                <div class="header1_short_code">
                    <?php
                    $shortcode_result = do_shortcode('[your_shortcode]');

                    if ( shortcode_exists( $settings['short_code'] ) ) {
                        echo do_shortcode($settings['short_code']);
                    }
                    ?>
                </div>
                <div class="mobile_toggle">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                </div>
            </div>
        </header>
        <?php
		echo '</div>';
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {}
}


