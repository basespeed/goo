<?php
get_templates_single();