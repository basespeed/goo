<?php
get_templates_search();