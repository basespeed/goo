<?php
get_templates_archive();